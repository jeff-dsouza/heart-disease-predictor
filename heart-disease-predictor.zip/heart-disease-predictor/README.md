# Heart Disease Prediction Web App

A machine learning-powered Streamlit app that predicts the risk of heart disease based on user input and CSV uploads. It preprocesses the data, trains multiple models, selects the best one, and gives prediction with probabilities.

## 🔗 Live Demo
[Click here to try the app](https://your-username.streamlit.app)  <!-- Replace with your actual deployed URL -->

## Features
- Upload CSV and train multiple models
- Preprocessing with imputation and scaling
- Uses Random Forest, SVM, MLP, and more
- Interactive prediction with sliders and dropdowns

## How to Run
1. Clone this repo
2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Run the app:
   ```
   streamlit run heart_app.py
   ```

## Author
Jeff Dsouza
